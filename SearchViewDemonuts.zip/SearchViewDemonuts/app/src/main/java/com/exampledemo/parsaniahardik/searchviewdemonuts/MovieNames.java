package com.exampledemo.parsaniahardik.searchviewdemonuts;

public class MovieNames {
    private String movieName;

    public MovieNames(String movieName) {
        this.movieName = movieName;
    }

    public String getAnimalName() {
        return this.movieName;
    }

}